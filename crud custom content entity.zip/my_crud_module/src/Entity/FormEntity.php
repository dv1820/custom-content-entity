<?php

namespace Drupal\my_crud_module\Entity;

use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityChangedTrait;

/**
 * Defines the FormEntity entity.
 *
 * @ContentEntityType(
 *   id = "form_entity",
 *   label = @Translation("Form Entity"),
 *   base_table = "form_entity",
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "firstname",
 *   },
 *   handlers = {
 *     "list_builder" = "Drupal\my_crud_module\Entity\FormEntityListBuilder",
 *     "form" = {
 *       "default" = "Drupal\my_crud_module\Form\FormEntityForm",
 *       "add" = "Drupal\my_crud_module\Form\FormEntityForm",
 *       "edit" = "Drupal\my_crud_module\Form\FormEntityForm",
 *       "delete" = "Drupal\my_crud_module\Form\FormEntityDeleteForm",
 *     },
 *   },
 *   admin_permission = "administer form entity",
 *   links = {
 *     "canonical" = "/form-entity/{form_entity}",
 *     "add-form" = "/form-entity/add",
 *     "edit-form" = "/form-entity/{form_entity}/edit",
 *     "delete-form" = "/form-entity/{form_entity}/delete"
 *   }
 * )
 */
class FormEntity extends ContentEntityBase {

  use EntityChangedTrait;

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['firstname'] = BaseFieldDefinition::create('string')
      ->setLabel(t('First Name'))
      ->setRequired(TRUE);

    $fields['lastname'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Last Name'))
      ->setRequired(TRUE);

    $fields['email'] = BaseFieldDefinition::create('email')
      ->setLabel(t('Email'))
      ->setRequired(TRUE);

    $fields['mobileno'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Mobile Number'))
      ->setRequired(TRUE);

    $fields['address'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Address'))
      ->setRequired(TRUE);

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Created'));

    return $fields;
  }
}
