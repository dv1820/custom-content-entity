<?php

namespace Drupal\my_crud_module\Entity;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Link;
use Drupal\Core\Url;

/**
 * Provides a list controller for FormEntity entities.
 */
class FormEntityListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header = [
      'id' => $this->t('ID'),
      'firstname' => $this->t('First Name'),
      'lastname' => $this->t('Last Name'),
      'email'    => $this->t('Email'),
      'mobileno' => $this->t('Mobile Number'),
      'address'  => $this->t('Address'),
    ];
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var \Drupal\my_crud_module\Entity\FormEntity $entity */
    $row = [
      'id' => $entity->id(),
      'firstname' => $entity->get('firstname')->value,
      'lastname' => $entity->get('lastname')->value,
      'email' => $entity->get('email')->value,
      'mobileno' => $entity->get('mobileno')->value,
      'address' => $entity->get('address')->value,
    ];
    return $row + parent::buildRow($entity);
  }

  /**
   * {@inheritdoc}
   */
  public function render() {
    // Get the parent render array.
    $build = parent::render();

    // Add a link to the 'Add New' form.
    $add_link = Link::fromTextAndUrl(
      $this->t('Add New Form'),
      Url::fromRoute('entity.form_entity.add_form') // Use the route you provided.
    )->toString();

    // Add the 'Add New' link to the render array.
    $build['add_new'] = [
      '#type' => 'markup',
      '#markup' => '<p>' . $add_link . '</p>',
    ];

    return $build;
  
}
}
